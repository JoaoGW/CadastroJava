
/**
 * Escreva uma descrição da classe Pessoa aqui.
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class Pessoa
{
    private int idade; //Armazena a idade de pessoa
    private NomePessoa nome; //Armazena a idade de Pessoa do tipo NomePessoa
    
    /**
     * Método getIdade
     *
     * @return O valor de retorno da idade que foi setado de alguma forma, seja diretamente
     * ou indiretamente
     */
    public int getIdade(){
        return this.idade;
    }
    
    /**
     * Método criarPessoa
     *
     * @param nome recebe um nome do tipo String
     * Este método cria uma nova pessoa de acordo com o nome dela
     */
    public void criarPessoa(String nome){
        setNome(new NomePessoa(nome));
    }
    
    /**
     * Método setNome
     *
     * @param nome do tipo NomePessoa
     * Este método dá a possibilidade de um nome ser definido/capturado para uso posterior
     */
    public void setNome(NomePessoa nome){
        try{
            this.nome = nome;
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
    
    /**
     * Método getNome
     *
     * @return O valor de retorno será o nome transformado em String, para que não haja erros
     * como caracteres indesejados dentro do nome
     */
    public String getNome(){
        return nome.toString();
    }
    
    /**
     * Método setIdade
     *
     * @param idade Um parâmetro do tipo inteiro que será recebido em alguma parte do código
     * Este método permite que o usuário defina a idade para alguma pessoa que está sendo cadastrada no momento
     */
    public void setIdade(int idade){
        try{
            this.idade = idade;
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
}
