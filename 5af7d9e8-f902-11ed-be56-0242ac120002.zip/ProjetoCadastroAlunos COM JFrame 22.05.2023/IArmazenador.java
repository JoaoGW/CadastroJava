
/**
 * IArmazenador é a interface de todas as funções que estão contidas dentro da classe de ArrayListImp
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public interface IArmazenador
{
    public void adicionarUsuarioAlunoArrayList(Object aluno);     
    public boolean estaVaziaArrayList();
    public void buscarUsuarioArrayList(String ra);
    public void removerUsuarioArrayList(String ra);
    public boolean getError();
    public void setError(boolean erro);
    public void listarUsuarioArrayList();
}