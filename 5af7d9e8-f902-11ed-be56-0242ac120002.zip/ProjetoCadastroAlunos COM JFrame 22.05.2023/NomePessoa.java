/**
 * Classe para armazenar o nome de uma pessoa. Possibilita inverter nome e limpar
 * espaços extras (operaçoes herdados da classe pai).
 * Retorna o nome da pessoa em formato de bibliografia
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class NomePessoa {
    // Atributos
    private Texto nome;

    // Construtores
    /**
     * NomePessoa Construtor
     *
     * @param nome o parâmetro irá receber um nome do tipo String vindo de alguma outra parte
     * do código
     */
    public NomePessoa(String nome){
        setNome(nome);
    }

    /**
     * @return the nome que será definido no metodo setNome, permite que o nome seja
     * devolvido de alguma maneira
     */
    public String getNome() {
        return this.nome.getTxt();
    }

    /**
     * @param nome será recebido de alguma outra parte do código e irá fazer uma nova
     * instanciação de nome do tipo Texto
     */
    protected void setNome(String nome) {
        try{
            this.nome = new Texto(nome);
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }

    /**
     * Retorna quantidade de palavras do nome
     * @return qtd numero de palavras
     */
    public int getQtdePalavras(){
        return this.nome.getQtdePalavras();
    }
    
    /**
     * Retorna nome invertido
     * @return sInv nome invertido
     */
    public String getNomeInvertido(){
        return this.nome.inverterTexto();
    }

    /**
     * Retorna nome bibliografico
     * @return sBib nome bibliografico
     */
    public String getNomeBiblio(){
        // Separa as palavras
        String vts[] = this.nome.getTxt().split(" ");
        int qtd = vts.length;

        String sBib = vts[qtd-1] + ", "; // ultimo nome + a virgula
        
        // Monta o texto o qual será exibido posteriormente
        for (int i=0; i < (qtd-1); i++){
            String pal = vts[i].toLowerCase(); // pega palavra
            if(!verificaStr(pal)){ // Se nao for preposicao concatena
                sBib = sBib + vts[i].toUpperCase().charAt(0) + ". ";
            }
        }
        return sBib;
    }

    /**
     * Verifica se string é uma String a ser retirada
     * @param s string a ser verificada
     * @return true eh preposicao false nao eh preposicao
     */
    private boolean verificaStr(String s){
        // Vetor de strings a serem retiradas
        final String sRet[]={"da", "de", "do", "di", "das", "dos", "e",};

        for (int i = 0; i < sRet.length; i++){
            if(sRet[i].equals(s)){
                return true;
            }
        }
        return false;
    }

    /**
     * Retorna os atributos de nome como string
     */
    public String toString(){
        try{
            return this.nome.toString();
        }catch(Exception e){
            return null;   
        }
    }
}

