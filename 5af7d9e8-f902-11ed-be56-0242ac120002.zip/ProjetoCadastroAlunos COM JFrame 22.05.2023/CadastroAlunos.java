
/**
 * Esta classe será a responsável por fazer o funcionamento principal do cadastro de todos 
 * os alunos da instituição, aqui estão os principais métodos e construtores. 
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class CadastroAlunos
{
    int e = 0;
    int n = 0;
    Aluno alunos[];
    
    /**
     * CadastroAlunos Construtor
     * Aqui armazenará todos os alunos que forem cadastrados, sendo o limite máximo
     * atualmente definido como 100 alunos.
     */
    CadastroAlunos (){
        alunos = new Aluno[100];
    }
    
    /**
     * Método Cadastro o qual será responsável por cadastrar definitivamente os dados
     * recebidos de um aluno em sua ficha de informações
     *
     * @param nome Um parâmetro do tipo String que conterá o nome inserido
     * @param idade Um parâmetro do tipo inteiro que conterá a idade inserida
     * @param serie Um parâmetro do tipo String que conterá a série inserida
     * @param ra Um parâmetro do tipo String que conterá o RA inserido
     */
    public void Cadastro(String nome,int idade,String serie,String ra){   
        cadNome(nome);
        cadIdade(idade);
        cadSerie(serie);  
        cadRa(ra);
    }
    
    /**
     * Método getRaCa
     * Este método retorna o RA do aluno em questão que está sendo requisitado
     *
     * @param p Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter o RA
     * @return O valor de retorno será o RA do aluno desejado
     */
    public String getRaCa(int p){
        try{
            return alunos[p].getRa();
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método getSerie
     * Este método retorna a série do aluno em questão que está sendo requisitado
     *
     * @param p Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter a série
     * @return O valor de retorno será a série do aluno desejado
     */
    public String getSerie(int p){
        try{
            return alunos[p].getSerie();
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método getIdade
     * Este método retorna a idade do aluno em questão que está sendo requisitado
     *
     * @param p Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter a idade
     * @return O valor de retorno será a idade do aluno desejado
     */
    public int getIdade(int p){
        try{
            return alunos[p].getIdade();   
        }catch(Exception e){
            return -1;
        }
    }
    
    /**
     * Método getNome
     * Este método retorna o nome do aluno em questão que está sendo requisitado
     *
     * @param p Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter o nome
     * @return O valor de retorno será o nome do aluno desejado
     */
    public String getNome(int p){
        try{
            return alunos[p].getNome();
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método getDisciplina
     * Este método retorna a disciplina do aluno em questão que está sendo requisitado
     *
     * @param posaluno Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter as disciplinas
     * @param posdisc Um parâmetro do tipo inteiro que é a posição respectiva da disciplina que se deseja ter as informações
     * @return O valor de retorno trará todas as informações requisitadas da disciplina em questão
     */
    public String getDisciplina(int posaluno,int posdisc){
        try{
            return alunos[posaluno].getDisc(posdisc);
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método getNota
     * Este método retorna as notas do aluno em questão que está sendo requisitado
     *
     * @param posaluno Um parâmetro do tipo inteiro que é a posição respectiva do aluno que se deseja ter as disciplinas
     * @param posdisc Um parâmetro do tipo inteiro que é a posição respectiva da disciplina que se deseja ter as informações
     * @return O valor de retorno trará todas as notas requisitadas da disciplina em questão
     */
    public float getNota(int posaluno,int posdisc){
        try{
            return alunos[posaluno].getNota(posdisc);   
        }catch(Exception e){
            return -1;
        }
    }
    
    /**
     * Método cadRa
     * Este método cadastra o RA dentro do aluno respectivo
     *
     * @param ra Um parâmetro do tipo String que conterá o ra que foi inserido
     * Este método cadastra o ra dentro do aluno respectivo
     */
    public void cadRa(String ra){     
        try{
            alunos[e].setRa(ra);
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
    
    /**
     * Método cadSerie
     * Este método cadastra a série dentro do aluno respectivo
     *
     * @param serie Um parâmetro do tipo String que será a série que foi inserida
     * 
     */
    public void cadSerie(String serie){
        try{
            alunos[e].setSerie(serie);
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
    
    /**
     * Método cadDisciplina
     * Este método cadastra a(s) disciplina(s) que serão inseridas dentro das informações do aluno
     *
     * @param disc Um parâmetro do tipo String que conterá o nome da disciplina
     * @param nota Um parâmetro do tipo float que conterá a nota da disciplina em questão
     * @param alunonovo Um parâmetro do tipo boolean que verifica se o aluno já possui cadastro armazenado ou se ele é um novo aluno ainda não cadastrado
     */
    public void cadDisciplina(String disc, float nota, boolean alunonovo){
        try{
            if(!disc.equals("")){
                if(alunonovo == true){
                    int v = verificarEspaco();
                    alunos[v] = new Aluno();
                    n = 0;
                }
                
                alunos[e].setDisciplina(disc,n,nota);
                n++;
                
                if(n >= 8){
                    disc = "";
                    n = 0;
                }
            }
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
    
    /**
     * Método cadNome
     * Este método cadastra o nome dentro do aluno respectivo
     *
     * @param nome Um parâmetro do tipo String que contém o nome que foi inserido
     */
    public void cadNome(String nome){
        try{
            alunos[e].criarPessoa(nome);
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
    
    /**
     * Método cadIdade
     * Este método cadastra a idade dentro do aluno respectivo
     *
     * @param idade Um parâmetro do tipo inteiro que contém a idade que foi inserida
     */
    public void cadIdade(int idade){
        try{
            alunos[e].setIdade(idade);
        }catch(Exception e){
            
        }
    }
    
    /**
     * Método verificarEspaco
     * Este método verifica se tem espaço para cadastrar um novo usuário
     *
     * @return O valor de retorno tem duas possibilidades: I) Um código de erro indicando que não há espaço suficiente (404). II) A posição que será possível armazenar o novo aluno cadastrado
     * 
     */
    public int verificarEspaco(){
        int er = 404;
        
        try{
            for(int i = 0; i < 100; i++){
                if(alunos[i] == null){
                    return i;
                }
            }
        }catch(Exception e){
            return er;   
        }
        return er;
    }
    
    /**
     * Método mostraAlunos
     * Este método tem como objetivo listar todos os alunos que já foram cadastrados de acordo com o RA que for solicitado/inserido
     *
     * @param listara Um parâmetro do tipo String que conterá o RA solicitado para exibir as informações
     */
    public void mostraAlunos(String listara){
        int i = 0;
        int j = 0;
        int tamanhodisc;
        String ra;
        
        try{
            while(alunos[i] != null){
                if(getRaCa(i).equals(listara)){
                    System.out.println(getRaCa(i));
                    //nome, idade, serie, disciplina e nota, ra 
                    System.out.println(getNome(i));
                    System.out.println(getIdade(i));
                    System.out.println(getSerie(i));
                    System.out.println(getRaCa(i));
                    System.out.println("Materias: ");
                    while(!alunos[i].getDisc(j).equals("")){
                        System.out.println(getDisciplina(i,j));
                        System.out.println(getNota(i,j));
                        j++;
                    }
                }
                i++;    
            }
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
}
