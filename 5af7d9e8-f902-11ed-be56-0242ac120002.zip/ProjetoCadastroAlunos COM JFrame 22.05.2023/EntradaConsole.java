import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * Entrada de dados (texto).
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */

public class EntradaConsole implements IMenu{
    Scanner scan = new Scanner( System.in );
    
    /**
     * lerIdade - entrada de idade (texto)
     *
     * @return int, idade fornecida
     */    
    public String lerNome(){ 
        try{
            System.out.println("Forneca nome: ");
            String nome = scan.nextLine();
            return nome;
        }catch(Exception e){
            return null;
        }
    }

    /**
     * lerIdade - entrada de idade (texto)
     *
     * @return int, idade fornecida
     */
    public String lerIdade(){
        try{
            System.out.println("Forneca idade: ");
            String idade = scan.nextLine();
            return idade;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerRa
     * Este tem como função registrar o RA que foi digitado
     *
     * @return O valor de retorno será o RA
     */
    public String lerRa()
    {
        try{
            System.out.println("Forneca RA: ");
            String ra = scan.nextLine();
            return ra;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerSerie
     * Este tem como função registrar a série que foi digitada
     *
     * @return O valor de retorno será a série
     */
    public String lerSerie()
    {
        try{
            System.out.println("Forneca serie: ");
            String serie = scan.nextLine();
            return serie;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerDisciplina
     * Este tem como função registrar a disciplina que foi digitada
     *
     * @return O valor de retorno será a disciplina
     */
    public String lerDisciplina()
    {
        try{
            System.out.println("Forneca disciplinas: ");
            String disciplina = scan.nextLine();
            return disciplina;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerNota
     *
     * Este tem como função registrar a nota que foi digitada
     *
     * @return O valor de retorno será a nota
     */
    public String lerNota(){ 
        try{
            System.out.println("Forneca nota: ");
            String nota = scan.nextLine();
            return nota;  
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerListaRa
     *
     * Este tem como função listar de acordo com o RA que foi digitado
     *
     * @return O valor de retorno será a idade
     */
    public String lerListaRa(){
        try{
            System.out.println("Forneca RA do aluno: ");
            String listara = scan.nextLine();
            return listara;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método Menu
     * Este método tem como função mostrar um pequeno menu ao usuário sobre todas as possibilidades
     * de tarefas que ele pode realizar dentro do programa
     *
     * @return O valor de retorno será do tipo inteiro e conterá a opção que foi desejada pelo usuário
     */
     public int Menu(){
        System.out.println("Programa Cadastro de Alunos");
        System.out.println("[1]Inserir");
        System.out.println("[2]Remover");
        System.out.println("[3]Listar");
        System.out.println("[4]Sair");
        
        int op = Integer.parseInt(JOptionPane.showInputDialog("Escolha opcao: "));
        op = scan.nextInt();
        
        return op;
    }
}