import javax.swing.JOptionPane;

/**
 * Esta classe contém todas as funções de cadastro em formato de JOptionPane
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class EntradaGUI implements IMenu
{
    /**
     * Método lerRa
     * Este tem como função registrar o RA que foi digitado
     *
     * @return O valor de retorno será o RA
     */
    public String lerRa(){
        try{
            String ra = JOptionPane.showInputDialog("Forneca ra: ");
            return ra;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerSerie
     * Este tem como função registrar a série que foi digitada
     *
     * @return O valor de retorno será a série
     */
    public String lerSerie(){
        try{
            String serie = JOptionPane.showInputDialog("Forneca serie: ");
            return serie;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerDisciplina
     * Este tem como função registrar a disciplina que foi digitada
     *
     * @return O valor de retorno será a disciplina
     */
    public String lerDisciplina(){
        try{
            String disciplina = JOptionPane.showInputDialog("Forneca a disciplina: ");
            return disciplina;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerNome
     * Este tem como função registrar o nome que foi digitado
     *
     * @return O valor de retorno será o nome
     */
    public String lerNome(){
        try{
            String nome = JOptionPane.showInputDialog("Forneca Nome: ");
            return nome;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerIdade
     * Este tem como função registrar a idade que foi digitada
     *
     * @return O valor de retorno será a idade
     */
    public String lerIdade(){
        try{
            String idade = JOptionPane.showInputDialog("Forneca idade: ");
            return idade;
        }catch(Exception e){
            return null;
        }
    }
    
    /**
     * Método lerNota
     *
     * Este tem como função registrar a nota que foi digitada
     *
     * @return O valor de retorno será a nota
     */
    public String lerNota(){
        try{
            String nota = JOptionPane.showInputDialog("Forneca Nota: ");
            return nota;
        }catch(Exception e){
            return null;
        }
    } 
    
    /**
     * Método lerListaRa
     *
     * Este tem como função listar de acordo com o RA que foi digitado
     *
     * @return O valor de retorno será a idade
     */
    public String lerListaRa(){
        try{
            String listara = JOptionPane.showInputDialog("RA do aluno:");
            return listara;
        }catch(Exception e){
            return null;
        }
    } 
    
    //inserir,remover,listar,sair
    /**
     * Método Menu
     * Este método tem como função mostrar um pequeno menu ao usuário sobre todas as possibilidades
     * de tarefas que ele pode realizar dentro do programa
     *
     * @return O valor de retorno será do tipo inteiro e conterá a opção que foi desejada pelo usuário
     */
    public int Menu(){
        int op;
        System.out.println("Programa Cadastro de Alunos");
        System.out.println("[1]Inserir");
        System.out.println("[2]Remover");
        System.out.println("[3]Listar");
        System.out.println("[4]Sair");
        op = Integer.parseInt(JOptionPane.showInputDialog("Escolha opcao: "));
        return op;
    }
}
