
/**
 * Esta classe contém todos os dados necessários em uma pessoa que será do Tipo Aluno.
 * Na hierarquia, aluno é um filho de Pessoa e alguns de seus métodos e variáveis poderão
 * vir de sua classe pai.
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class Aluno extends Pessoa
{
    private String ra;
    private String serie;
    Disciplina discs[];
   
    /**
     * Aluno Construtor
     * Este construtor irá conter todos os dados necessários básicos para o aluno que serão
     * adicionados posteriormente, é o responsável por criar o objeto em memória.
     */
    Aluno(){
        setRa("a");
        setSerie("a");
        discs = new Disciplina[10];
    }
   
    //getters
    /**
     * Método getRa
     *
     * @return O valor de retorno será o RA daquele aluno específico
     */
    public String getRa(){
       return this.ra; 
    }
    
    /**
     * Método getSerie
     *
     * @return O valor de retorno será a série daquele aluno específico
     */
    public String getSerie(){
        return this.serie;
    } 
    
    //setters
    
    /**
     * Método setRa
     *
     * @param ra Um parâmetro do tipo String que conterá o RA
     * @return O valor de retorno será o ra que foi inserido
     */
    public String setRa(String  ra){
        this.ra = ra;
        return ra;    
    }
    
    /**
     * Método setSerie
     *
     * @param serie Um parâmetro do tipo String que conterá a série
     * @return O valor de retorno será a série que foi inserida
     */
    public String setSerie(String serie){
        this.serie = serie;
        return serie;
    }
    
    /**
     * Método setDisciplina
     *
     * @param disc Um parâmetro do tipo String que conterá as disciplinas
     * @param n Um parâmetro do tipo int que irá definir a quantidade de disciplinas a serem adicionadas
     * @param nota Um parâmetro do tipo float que conterá todas as notas das disciplinas que foram inseridads.
     */
    public void setDisciplina(String disc, int n, float nota){
        try{
            discs[n] = new Disciplina();
            discs[n].criaDisc(disc);
            discs[n].setNota(nota);
        }catch(Exception e){
            System.out.println("Não foi possível concluir esta operação. Por favor, tente novamente!");
        }
    }
    
    /**
     * Método getNota
     *
     * @param n Um parâmetro do tipo inteiro que será a posição do array que está aquele matéria
     * @return O valor de retorno de acordo com a matéria desejada em n e sua respectiva nota
     */
    public float getNota(int n){
        try{
            return discs[n].getNota();
        }catch(Exception e){
            return -1;
        }
    }

    /**
     * Método getDisc
     *
     * @param n Um parâmetro do tipo inteiro que será a posição da disciplina em questão
     * @return O valor de retorno será o nome da disciplina que se quer o nome
     */
    public String getDisc(int n){
        try{
           if(discs[n] == null){
               return ""; 
           }
           return discs[n].getNomeDisc();
        }catch(Exception e){
            return null;
        }
    } 
}
