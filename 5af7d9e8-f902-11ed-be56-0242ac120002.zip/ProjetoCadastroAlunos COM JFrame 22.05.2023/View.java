import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JTextField;

/**
 * Esta classe conterá todas as funcionalidades básicas relacionadas a exibição de paineis e console
 * 
 * @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
 * @version 2.0 2023/05/22
 */
public class View extends JFrame implements ActionListener
{
    // ============ INICIALIZADORES =============
    // menu inicial
    private JButton btnInserir, btnListar, btnRemover, btnSair;
    // menu inserir
    private JLabel lblNome, lblIdade, lblRa, lblNota, lblSerie;
    private JTextField txfNome, txfIdade,txfRa, txfSerie;
    private JComboBox cbDisciplinas;
    private JLabel lblNomeDisc, lblNotaDisc;
    private JButton btnConfirmaDisciplinas, btnConfirmaInserir, btnCancelaInserir;

    /**
     * View Construtor
     * Contém todos métodos essenciais que essa classe proporciona
     *
     * @param nomeStr Um parâmetro
     */
    public View(String nomeStr){
        Menu();
        CriaFieldDiscAux();
    }

    // ================ MENU INICIAL ================
    /**
     * Método Menu
     * Reponsável por criar o menu inicial da aplicação, aqui se encontram as opção de Inserir, Listar,
     * Remover e Sair no formato gráfico o qual utiliza-se da biblioteca externa do JFrame
     */
    private void Menu(){
        // Cria o FRAME
        JFrame frame = new JFrame("MENU INICIAL");
        frame.setSize(600,80);

        // Cria o PAINEL
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(1, 4, 30, 100));

        // Cria 4 botoes do MENU
        btnInserir = new JButton("Inserir");
        btnInserir.addActionListener(this);
        btnListar = new JButton("Listar");
        btnListar.addActionListener(this);
        btnRemover = new JButton("Remover");
        btnRemover.addActionListener(this);
        btnSair = new JButton("Sair");
        btnSair.addActionListener(this);

        // Bota os 4 botoes no PAINEL
        painel.add(btnInserir);
        painel.add(btnListar);
        painel.add(btnRemover);
        painel.add(btnSair);

        // Bota o PAINEL no FRAME
        frame.add(painel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true);
        frame.setResizable(false);
    }

    // ================ MENU INSERIR ================
    JFrame frameIns = new JFrame("MENU INSERIR");
    JPanel painelIns = new JPanel();
    /**
     * Método Inserir
     * Este será responsável por abrir o menu gráfico de inserção de dados de um novo aluno
     */
    private void Inserir(){
        // Cria o FRAME
        frameIns.setSize(600, 200);

        // Cria o PAINEL
        painelIns.setLayout(new GridLayout(6, 2, 10, 10));

        // cria 5 labels, 3 fields, 1 botao, 1 combo box
        lblNome = new JLabel("    Nome:");
        txfNome = new JTextField(10);
        lblIdade = new JLabel("    Idade:");
        txfIdade = new JTextField(10);
        lblRa = new JLabel("    Ra:");
        txfRa = new JTextField(10);
        lblSerie = new JLabel("    Serie:");
        txfSerie = new JTextField(10);
        String[] strDisc = {"Quantidade de materias:", "1", "2", "3", "4", "5", "6", "7", "8"};
        cbDisciplinas = new JComboBox(strDisc);
        cbDisciplinas.addActionListener(this);
        btnConfirmaDisciplinas = new JButton("Confirmar a qnt de disciplinas");
        btnConfirmaDisciplinas.addActionListener(this);
        lblNomeDisc = new JLabel("Nome da materia:");
        lblNotaDisc = new JLabel("Nota:");

        // Bota td acima no PAINEL GERAL
        painelIns.add(lblNome);
        painelIns.add(txfNome);
        painelIns.add(lblIdade);
        painelIns.add(txfIdade);
        painelIns.add(lblRa);
        painelIns.add(txfRa);
        painelIns.add(lblSerie);
        painelIns.add(txfSerie);
        painelIns.add(cbDisciplinas);
        painelIns.add(btnConfirmaDisciplinas);
        painelIns.add(lblNomeDisc);
        painelIns.add(lblNotaDisc);

        // Bota PAINEL no FRAME
        frameIns.add(painelIns);

        frameIns.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frameIns.setVisible(true);
        frameIns.setResizable(true);
    }

    // ================ MENU LISTAR ================
    /**
     * Método Listar
     * Este será responsável por abrir o menu gráfico de listar os dados de um aluno
     */
    private void Listar(){
        JFrame frameListar = new JFrame("MENU LISTAR");
        frameListar.setSize(500, 60);
        JPanel painelListar = new JPanel();
        painelListar.setLayout(new GridLayout(1,3,15,15));

        // inicializa 1 label 1 txf 1 botao
        JLabel lblNomeListar;
        JTextField txfNomeListar;
        JButton btnConfirmaListar;

        // cria novo 1 do label, 1 do txf, 1 botao
        lblNomeListar = new JLabel("Nome do aluno: ");
        txfNomeListar = new JTextField(10);
        txfNomeListar.addActionListener(this);
        btnConfirmaListar = new JButton("procurar");
        btnConfirmaListar.addActionListener(this);

        // bota a label e o txf no PAINEL
        painelListar.add(lblNomeListar);
        painelListar.add(txfNomeListar);
        painelListar.add(btnConfirmaListar);

        // bota o PAINEL no FRAME
        frameListar.add(painelListar);

        frameListar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frameListar.setVisible(true);
        frameListar.setResizable(false);
    }
    
    // ================ CRIA OS FIELDS DE MATERIAS ================
    int qntOld;
    int qntDisc;
    JTextField[] txfNomeDisc = new JTextField[10];
    JTextField[] txfNotaDisc = new JTextField[10];
    /**
     * Método CriaFieldDiscAux
     * Este terá como função criar o campo de inserção das disciplinas de um aluno, com mais duas opções extras de cancelar ou finalizar
     */
    private void CriaFieldDiscAux(){
        for (int i=0; i<10; i++){
            txfNomeDisc[i] = new JTextField();
            txfNotaDisc[i] = new JTextField();
        }

        btnCancelaInserir = new JButton("Cancelar o cadastro");
        btnConfirmaInserir = new JButton("Finalizar o cadastro");
    }

    /**
     * Método CriaTxfDisc
     * Este terá como função criar um painel e mostrar no formato Grid todos as disciplinas
     */
    private void CriaTxfDisc(){
        // pega oq ta no ComboBox e passa pra um int
        qntDisc = Integer.parseInt((String)cbDisciplinas.getSelectedItem());

        int tamanhoFrameIns = 250;
        int tamanhoGridIns = 7;

        // SE QND clicar no botao dnv, eu escolher um numero menor
        // q da ultima vez, remove os antigos
        if (qntOld > qntDisc){
            for (int i=qntOld; i>=qntDisc; i--){
                painelIns.remove(txfNomeDisc[i]);
                painelIns.remove(txfNotaDisc[i]);
            }
        }

        // Bota os novos TextFields
        for (int i=0; i<qntDisc; i++){
            // aumenta tamanho do frame e grid
            tamanhoFrameIns += 50;
            tamanhoGridIns += 1;

            // adiciona as labels
            painelIns.add(txfNomeDisc[i]);
            painelIns.add(txfNotaDisc[i]);
        }
        qntOld = qntDisc;

        // adiciona o botao "Cancelar" e "Confirmar"
        painelIns.add(btnCancelaInserir);
        btnCancelaInserir.addActionListener(this);
        painelIns.add(btnConfirmaInserir);
        btnConfirmaInserir.addActionListener(this);

        // aumenta ou diminui o painel de acordo com as variaveis
        painelIns.setLayout(new GridLayout(tamanhoGridIns, 2, 10, 10));
        frameIns.setSize(600, tamanhoFrameIns);

        // bota o PAINEL INS no frame
        frameIns.add(painelIns);
    }

    /**
     * Método ConfirmaInserir
     * Tem como função confirmar se as informações inseridas estão corretas de acordo com o que o usuário
     * inseriu. Além disso este método também terá como objetivo colocar as notas para uma matéria e depois
     * mostrar uma a uma as notas que foram inseridas de acordo com a disciplina respectiva
     */
    private void ConfirmaInserir(){
        String[] nomeDisc = new String[10];
        float[] notaDisc = new float[10];
        // TEM TAMBEM O INT "qntDisc"

        System.out.println("Nome: " + this.lerNome());
        System.out.println("Idade: " + this.lerIdade());
        System.out.println("RA: " + this.lerRa());
        System.out.println("Serie: " + this.lerSerie());

        for (int i=0; i<qntDisc; i++){
            nomeDisc[i] = txfNomeDisc[i].getText();
            int x = i + 1;
            try{
                float aux;
                aux = Float.parseFloat(txfNotaDisc[i].getText());

                if (aux < 0 || aux > 10){
                    JOptionPane.showMessageDialog(null,
                        " Insira um nota entre 0 e 10 para a materia ["  + x + "] ");
                }
                else{
                    notaDisc[i] = aux;
                }

                System.out.println("Nome mat" + i + ": " + nomeDisc[i]);
                System.out.println("Nota mat" + i + ": " + notaDisc[i]);
            }
            catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null,
                    " Insira uma nota valida para a materia [" + x + "].");
            }
        }
    }

    // ============== GETTERS DO CONFIRMA DISCIPLINAS ===============
    /**
     * Método lerNome
     * Este tem como função devolver um nome que foi inserido
     *
     * @return O valor de retorno será do tipo String o nome que foi inserido
     */
    public String lerNome(){
        String nome = txfNome.getText();
        return nome;
    }
    
    /**
     * Método lerIdade
     * Este tem como função devolver a idade que foi inserida, se não estiver de acordo com os padrões selecionados,
     * ou seja maior que 0 ou menor que 100, o usuário será solicitado para inserir novamente e desta vez
     * seguindo o padrão pré-estabelecido
     *
     * @return O valor de retorno será a idade definitiva devidamente tratada
     */
    public int lerIdade(){
        int idade = 0;
        try{
            int aux = Integer.parseInt(txfIdade.getText());
            if (aux <= 0 || aux > 100){
                JOptionPane.showMessageDialog(null,
                    " Insira um numero entre 0 e 100 para a idade");
            }
            else{
                idade = aux;            
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null,
                " Insira apenas numeros para a idade ");
        }
        return idade;
    }  
    
    /**
     * Método lerRa
     * Este tem como função devolver o ra que foi inserido, se não estiver de acordo com os padrões selecionados,
     * ou seja maior que 0 ou menor que 99999999, o usuário será solicitado para inserir novamente e desta vez
     * seguindo o padrão pré-estabelecido
     *
     * @return O valor de retorno será o RA definitivo devidamente tratado
     */
    public int lerRa(){
        int ra = 0;
        try{
            int aux = Integer.parseInt(txfRa.getText());
            if (aux <= 0 || aux > 99999999){
                JOptionPane.showMessageDialog(null,
                    " Insira um numero maior que 0 com ate 10 caracteres para o RA(caso tenha menos que 10, sera inserido 0 na frente) ");
            }
            else{
                ra = aux;
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null,
                " Insira apenas numeros no RA ");
        }
        return ra;
    }
    
    /**
     * Método lerSerie
     * Este tem como função devolver a série que foi inserida, se não estiver de acordo com os padrões selecionados,
     * ou seja maior que 0 ou menor que 12, o usuário será solicitado para inserir novamente e desta vez
     * seguindo o padrão pré-estabelecido
     *
     * @return O valor de retorno será a série definitiva devidamente tratada
     */
    public int lerSerie(){
        int serie = 0;
        
        try{
            int aux = Integer.parseInt(txfSerie.getText());
            if (aux <= 0 || aux>12){
                JOptionPane.showMessageDialog(null,
                    " Insira um numero entre 0 e 12 para a serie ");
            }
            else{
                serie = aux;
            }
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null,
                " Insira apenas numeros para a serie");
        }
        
        return serie;
    }
    
    /**
     * Método lerQntDisc
     * Este método tem como função retornar a quantidade de disciplinas
     *
     * @return O valor de retorno será a quantidade de disciplinas
     */
    public int lerQntDisc(){
        return qntDisc;
    }
    
    /**
     * Método lerNotaDisc
     * Este tem como função devolver a nota que foi inserida, se não estiver de acordo com os padrões selecionados,
     * ou seja maior que 0 ou menor ou igual que 10, o usuário será solicitado para inserir novamente e desta vez
     * seguindo o padrão pré-estabelecido
     *
     * @return O valor de retorno será a nota que foi inserida
     */
    public float lerNotaDisc(int x){
        float notaDisc = 0;
        
        try{
            float aux;
            aux = Float.parseFloat(txfNotaDisc[x].getText());

            if (aux < 0 || aux > 10){
                JOptionPane.showMessageDialog(null,
                    " Insira um nota entre 0 e 10 para a materia ["  + x + "] ");
            }
            else{
                notaDisc = aux;
            }

            System.out.println("Nota mat" + x + ": " + notaDisc);
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null,
                " Insira uma nota valida para a materia [" + x + "].");
        }
        
        return notaDisc;
    }

    // ============== ACTION LISTENER ===============
    /**
     * Método actionPerformed
     * Esta função trata um evento semântico que indica que ocorreu uma ação definida pelo componente. 
     * Este evento de alto nível é gerado por um componente, no caso os botões de inserir, disciplinas,
     * listar, confirmar e cancelar
     *
     * @param e Um parâmetro que captura a ação
     */
    public void actionPerformed(ActionEvent e){
        // caso clique INSERIR
        if (e.getSource() == btnInserir){
            Inserir();
            System.out.println("clicou btnInserir");
        }
        // caso clique LISTAR
        else if(e.getSource() == btnListar){
            Listar();
            System.out.println("clicou btnListar");
        }

        // ======= INSERIR =======
        // caso clique CONFIRMAR QNT MATERIAS
        if (e.getSource() == btnConfirmaDisciplinas){
            CriaTxfDisc();
            System.out.println("clicou btnConfirmaDisciplinas");
        }
        
        // caso clique CONFIRMAR INSERIR
        if (e.getSource() == btnConfirmaInserir){
            ConfirmaInserir();
            System.out.println("clicou btnConfirmaInserir");
        }
        
        // caso clique CANCELAR INSERIR
        if (e.getSource() == btnCancelaInserir){

        }
    }
}