import javax.swing.JOptionPane;

/**
* Classe TestaNomePessoa
*
* Esta classe será a responsável por testar o nome da pessoa e entregar todas as modificações desejadas
* no programa, isso inclui o nome normal, invertido e bibliográfico no momento.
* 
* @author Giovana Akemi Maeda, Lucas Kenji Hayashi, João Pedro Ribeiro, Pedro Marques Prado
* @version 2.0 2023/05/22
*/
public class TestaNomePessoa {
    /**
     * Método main
     *
     * Este método será responsável por modificar o nome nos seguintes formatos:
     * Nome normal (sem modificações), nome invertido e nome bibliográfico
     */
    public static void main(String[] args) {
        // Entrada de um nome (atraves do teclado)
        String nomePessoa = JOptionPane.showInputDialog("Forneça um nome: ");

        // Criacao de uma instancia da classe nome (criacao do objeto)
        NomePessoa nome = new NomePessoa(nomePessoa); // Chama o metodo construtor com o texto fornecido

        try{
            // Mostra os dados
            System.out.println("Nome              : " + nome.getNome() + " (" + nome.getQtdePalavras()+ " palavras)");
            System.out.println("Nome invertido    : " + nome.getNomeInvertido());
            System.out.println("Nome bibliografico: " + nome.getNomeBiblio());
        }catch(Exception e){
            System.out.println("Não foi possível concluir alguma das operações, por favor verifique se o nome inserido está correto e não contém nenhum erro de digitação.");
        }
    }
}
