
/**
 * Escreva a descrição da interface IMenuArrayList aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface IMenuArrayList
{
    /**
     * Exemplo de um cabeçalho de método - substitua este comentário pelo seu
     * 
     * @param  y    exemplo de um parâmetro de método
     * @return        o resultado produzido pelo sampleMethod 
     */
    int sampleMethod(int y);
}
