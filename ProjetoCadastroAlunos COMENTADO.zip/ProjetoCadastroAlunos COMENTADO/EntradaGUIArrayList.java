
/**
 * Escreva uma descrição da classe EntradaGUIArrayList aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class EntradaGUIArrayList implements IMenuArrayList
{
    
}
