
/**
 * Escreva uma descrição da classe EntradaConsole aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class EntradaConsole
{
   
}
