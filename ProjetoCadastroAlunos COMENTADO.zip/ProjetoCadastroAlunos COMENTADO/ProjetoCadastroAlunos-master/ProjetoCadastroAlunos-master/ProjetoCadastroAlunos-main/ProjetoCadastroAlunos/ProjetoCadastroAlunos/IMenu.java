
/**
 * Escreva a descrição da interface IMenu aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface IMenu
{
   public String lerRa();
   public String lerNome();
   public String lerDisciplina();
   public String lerNota();
   public String lerIdade();
   public String lerSerie();
   public int Menu();
}
